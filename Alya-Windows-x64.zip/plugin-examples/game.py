"""An external Alya tool plugin. No imports from Alya and no core rebuild required.
Line-delimited JSON-RPC over stdin/stdout; logs belong on stderr.
"""
import json
import sys

sys.stdin.reconfigure(encoding="utf-8")
sys.stdout.reconfigure(encoding="utf-8")

positions = {}

def handle(method, params):
    if method == 'initialize':
        return {'sdk_version': 1}
    if method == 'shutdown':
        return {'ok': True}
    if method == 'receive':
        return []
    if method == 'invoke':
        scope = params['scope']
        key = (scope['owner'], scope['chat'])
        position = positions.setdefault(key, [0, 0])
        if params['function'] == 'move':
            direction = params['arguments']['direction']
            dx, dy = {'left': (-1,0), 'right': (1,0), 'up': (0,-1), 'down': (0,1)}[direction]
            position[:] = [max(-5, min(5, position[0] + dx)), max(-5, min(5, position[1] + dy))]
        return {'position': position, 'target': [3, 2], 'won': position == [3,2]}
    if method == 'erase_identity':
        owner = params['owner']
        for key in list(positions):
            if key[0] == owner:
                del positions[key]
        return {'erased': True}
    if method == 'acknowledge':
        return {'ok': True}
    raise ValueError('unsupported method')

for line in sys.stdin:
    request = {}
    try:
        request = json.loads(line)
        result = handle(request['method'], request.get('params', {}))
        response = {'jsonrpc': '2.0', 'id': request['id'], 'result': result}
    except Exception:
        response = {'jsonrpc': '2.0', 'id': request.get('id') if isinstance(request, dict) else None, 'error': {'code': -32000, 'message': 'plugin request failed'}}
    print(json.dumps(response, ensure_ascii=False), flush=True)

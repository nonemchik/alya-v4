# Third-party notices

This release uses the following packages resolved for the Windows executable.
Original license and notice files are included under THIRD_PARTY_LICENSES. SOURCE.json
records the package version, declared SPDX license and upstream repository. Build-time
dependencies are included; workspace crates use the project's MIT license.

Telegram MTProto is provided by grammers 0.12.0 and its generated TL types; their
upstream notices are included. The Obsidian layout takes inspiration from
[eugeniughelbur/obsidian-second-brain](https://github.com/eugeniughelbur/obsidian-second-brain).
Its installer and hooks are not included or executed; attribution also appears in Brain Index.

| Package | Declared license | Included notices |
| --- | --- | --- |
| adler2-2.0.1 | 0BSD OR MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/adler2-2.0.1/) |
| aes-0.9.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/aes-0.9.4/) |
| ahash-0.8.12 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ahash-0.8.12/) |
| aho-corasick-1.1.5 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/aho-corasick-1.1.5/) |
| anstream-1.0.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/anstream-1.0.0/) |
| anstyle-1.0.14 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/anstyle-1.0.14/) |
| anstyle-parse-1.0.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/anstyle-parse-1.0.0/) |
| anstyle-query-1.1.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/anstyle-query-1.1.5/) |
| anstyle-wincon-3.0.11 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/anstyle-wincon-3.0.11/) |
| anyhow-1.0.104 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/anyhow-1.0.104/) |
| async-trait-0.1.92 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/async-trait-0.1.92/) |
| atomic-waker-1.1.2 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/atomic-waker-1.1.2/) |
| autocfg-1.5.1 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/autocfg-1.5.1/) |
| axum-0.8.9 | MIT | [Notices](THIRD_PARTY_LICENSES/axum-0.8.9/) |
| axum-core-0.5.6 | MIT | [Notices](THIRD_PARTY_LICENSES/axum-core-0.5.6/) |
| base16ct-1.0.0 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/base16ct-1.0.0/) |
| base64-0.22.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/base64-0.22.1/) |
| base64-0.23.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/base64-0.23.1/) |
| bit-set-0.8.0 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/bit-set-0.8.0/) |
| bit-vec-0.8.0 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/bit-vec-0.8.0/) |
| bitflags-2.13.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/bitflags-2.13.2/) |
| block-buffer-0.10.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/block-buffer-0.10.4/) |
| block-buffer-0.12.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/block-buffer-0.12.1/) |
| borrow-or-share-0.2.4 | MIT-0 | [Notices](THIRD_PARTY_LICENSES/borrow-or-share-0.2.4/) |
| bs58-0.5.1 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/bs58-0.5.1/) |
| bytecount-0.6.9 | Apache-2.0/MIT | [Notices](THIRD_PARTY_LICENSES/bytecount-0.6.9/) |
| bytemuck-1.25.2 | Zlib OR Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/bytemuck-1.25.2/) |
| byteorder-lite-0.1.0 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/byteorder-lite-0.1.0/) |
| bytes-1.12.1 | MIT | [Notices](THIRD_PARTY_LICENSES/bytes-1.12.1/) |
| cc-1.11.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/cc-1.11.1/) |
| cfg-if-1.0.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/cfg-if-1.0.5/) |
| cfg_aliases-0.2.2 | MIT | [Notices](THIRD_PARTY_LICENSES/cfg_aliases-0.2.2/) |
| chacha20-0.10.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/chacha20-0.10.2/) |
| chrono-0.4.45 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/chrono-0.4.45/) |
| cipher-0.5.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/cipher-0.5.2/) |
| clap-4.6.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/clap-4.6.7/) |
| clap_builder-4.6.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/clap_builder-4.6.7/) |
| clap_derive-4.6.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/clap_derive-4.6.7/) |
| clap_lex-1.1.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/clap_lex-1.1.1/) |
| cmov-0.5.4 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/cmov-0.5.4/) |
| colorchoice-1.0.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/colorchoice-1.0.5/) |
| const-oid-0.10.3 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/const-oid-0.10.3/) |
| cpubits-0.1.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/cpubits-0.1.1/) |
| cpufeatures-0.2.17 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/cpufeatures-0.2.17/) |
| cpufeatures-0.3.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/cpufeatures-0.3.1/) |
| crc32fast-1.5.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/crc32fast-1.5.5/) |
| crossbeam-deque-0.8.8 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/crossbeam-deque-0.8.8/) |
| crossbeam-epoch-0.9.21 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/crossbeam-epoch-0.9.21/) |
| crossbeam-utils-0.8.23 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/crossbeam-utils-0.8.23/) |
| crypto-bigint-0.7.11 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/crypto-bigint-0.7.11/) |
| crypto-common-0.1.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/crypto-common-0.1.7/) |
| crypto-common-0.2.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/crypto-common-0.2.2/) |
| crypto-primes-0.7.2 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/crypto-primes-0.7.2/) |
| ctr-0.10.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ctr-0.10.1/) |
| ctutils-0.4.8 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/ctutils-0.4.8/) |
| darling-0.24.1 | MIT | [Notices](THIRD_PARTY_LICENSES/darling-0.24.1/) |
| darling_core-0.24.1 | MIT | [Notices](THIRD_PARTY_LICENSES/darling_core-0.24.1/) |
| darling_macro-0.24.1 | MIT | [Notices](THIRD_PARTY_LICENSES/darling_macro-0.24.1/) |
| deranged-0.5.9 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/deranged-0.5.9/) |
| digest-0.10.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/digest-0.10.7/) |
| digest-0.11.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/digest-0.11.3/) |
| displaydoc-0.2.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/displaydoc-0.2.7/) |
| dotenvy-0.15.7 | MIT | [Notices](THIRD_PARTY_LICENSES/dotenvy-0.15.7/) |
| dyn-clone-1.0.20 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/dyn-clone-1.0.20/) |
| either-1.19.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/either-1.19.0/) |
| email_address-0.2.9 | MIT | [Notices](THIRD_PARTY_LICENSES/email_address-0.2.9/) |
| equivalent-1.0.3 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/equivalent-1.0.3/) |
| fallible-iterator-0.3.0 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/fallible-iterator-0.3.0/) |
| fallible-streaming-iterator-0.1.9 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/fallible-streaming-iterator-0.1.9/) |
| fancy-regex-0.16.2 | MIT | [Notices](THIRD_PARTY_LICENSES/fancy-regex-0.16.2/) |
| fastrand-2.5.0 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/fastrand-2.5.0/) |
| fdeflate-0.3.7 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/fdeflate-0.3.7/) |
| find-msvc-tools-0.1.15 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/find-msvc-tools-0.1.15/) |
| flate2-1.1.11 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/flate2-1.1.11/) |
| fluent-uri-0.3.2 | MIT | [Notices](THIRD_PARTY_LICENSES/fluent-uri-0.3.2/) |
| foldhash-0.1.5 | Zlib | [Notices](THIRD_PARTY_LICENSES/foldhash-0.1.5/) |
| form_urlencoded-1.2.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/form_urlencoded-1.2.2/) |
| fraction-0.15.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/fraction-0.15.4/) |
| futures-channel-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-channel-0.3.34/) |
| futures-core-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-core-0.3.34/) |
| futures-io-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-io-0.3.34/) |
| futures-macro-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-macro-0.3.34/) |
| futures-sink-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-sink-0.3.34/) |
| futures-task-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-task-0.3.34/) |
| futures-util-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/futures-util-0.3.34/) |
| generic-array-0.14.7 | MIT | [Notices](THIRD_PARTY_LICENSES/generic-array-0.14.7/) |
| getrandom-0.2.17 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/getrandom-0.2.17/) |
| getrandom-0.3.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/getrandom-0.3.4/) |
| getrandom-0.4.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/getrandom-0.4.3/) |
| glass_pumpkin-2.0.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/glass_pumpkin-2.0.0/) |
| grammers-client-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-client-0.12.0/) |
| grammers-crypto-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-crypto-0.12.0/) |
| grammers-mtproto-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-mtproto-0.12.0/) |
| grammers-mtsender-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-mtsender-0.12.0/) |
| grammers-session-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-session-0.12.0/) |
| grammers-tl-gen-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-tl-gen-0.12.0/) |
| grammers-tl-parser-2.0.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-tl-parser-2.0.0/) |
| grammers-tl-types-0.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/grammers-tl-types-0.12.0/) |
| hashbrown-0.12.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hashbrown-0.12.3/) |
| hashbrown-0.15.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hashbrown-0.15.5/) |
| hashbrown-0.17.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hashbrown-0.17.1/) |
| hashlink-0.10.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hashlink-0.10.0/) |
| heck-0.5.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/heck-0.5.0/) |
| hex-0.4.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hex-0.4.3/) |
| hmac-0.13.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hmac-0.13.0/) |
| http-1.5.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/http-1.5.0/) |
| http-body-1.1.0 | MIT | [Notices](THIRD_PARTY_LICENSES/http-body-1.1.0/) |
| http-body-util-0.1.5 | MIT | [Notices](THIRD_PARTY_LICENSES/http-body-util-0.1.5/) |
| httparse-1.10.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/httparse-1.10.1/) |
| httpdate-1.0.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/httpdate-1.0.3/) |
| hybrid-array-0.4.15 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/hybrid-array-0.4.15/) |
| hyper-1.12.0 | MIT | [Notices](THIRD_PARTY_LICENSES/hyper-1.12.0/) |
| hyper-rustls-0.27.10 | Apache-2.0 OR ISC OR MIT | [Notices](THIRD_PARTY_LICENSES/hyper-rustls-0.27.10/) |
| hyper-util-0.1.21 | MIT | [Notices](THIRD_PARTY_LICENSES/hyper-util-0.1.21/) |
| icu_collections-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_collections-2.4.0/) |
| icu_locale_core-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_locale_core-2.4.0/) |
| icu_normalizer-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_normalizer-2.4.0/) |
| icu_normalizer_data-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_normalizer_data-2.4.0/) |
| icu_properties-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_properties-2.4.0/) |
| icu_properties_data-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_properties_data-2.4.0/) |
| icu_provider-2.4.0 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/icu_provider-2.4.0/) |
| ident_case-1.0.1 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ident_case-1.0.1/) |
| idna-1.1.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/idna-1.1.0/) |
| idna_adapter-1.2.2 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/idna_adapter-1.2.2/) |
| image-0.25.10 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/image-0.25.10/) |
| image-webp-0.2.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/image-webp-0.2.4/) |
| indexmap-1.9.3 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/indexmap-1.9.3/) |
| indexmap-2.14.2 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/indexmap-2.14.2/) |
| inout-0.2.6 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/inout-0.2.6/) |
| instant-distance-0.6.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/instant-distance-0.6.1/) |
| ipnet-2.12.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ipnet-2.12.2/) |
| is_terminal_polyfill-1.70.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/is_terminal_polyfill-1.70.2/) |
| itoa-1.0.19 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/itoa-1.0.19/) |
| jiff-0.2.43 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/jiff-0.2.43/) |
| jiff-core-0.1.5 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/jiff-core-0.1.5/) |
| jiff-static-0.2.43 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/jiff-static-0.2.43/) |
| jiff-tzdb-0.1.9 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/jiff-tzdb-0.1.9/) |
| jiff-tzdb-platform-0.1.3 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/jiff-tzdb-platform-0.1.3/) |
| jsonschema-0.33.0 | MIT | [Notices](THIRD_PARTY_LICENSES/jsonschema-0.33.0/) |
| lazy_static-1.5.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/lazy_static-1.5.1/) |
| libc-0.2.191 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/libc-0.2.191/) |
| libsqlite3-sys-0.35.0 | MIT | [Notices](THIRD_PARTY_LICENSES/libsqlite3-sys-0.35.0/) |
| litemap-0.8.3 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/litemap-0.8.3/) |
| locate-locale-0.2.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/locate-locale-0.2.0/) |
| lock_api-0.4.14 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/lock_api-0.4.14/) |
| log-0.4.35 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/log-0.4.35/) |
| lru-slab-0.1.3 | MIT OR Apache-2.0 OR Zlib | [Notices](THIRD_PARTY_LICENSES/lru-slab-0.1.3/) |
| matchers-0.2.0 | MIT | [Notices](THIRD_PARTY_LICENSES/matchers-0.2.0/) |
| matchit-0.8.4 | MIT AND BSD-3-Clause | [Notices](THIRD_PARTY_LICENSES/matchit-0.8.4/) |
| md5-0.8.1 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/md5-0.8.1/) |
| memchr-2.8.3 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/memchr-2.8.3/) |
| mime-0.3.18 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/mime-0.3.18/) |
| mime_guess-2.0.5 | MIT | [Notices](THIRD_PARTY_LICENSES/mime_guess-2.0.5/) |
| miniz_oxide-0.8.9 | MIT OR Zlib OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/miniz_oxide-0.8.9/) |
| miniz_oxide-0.9.1 | MIT OR Zlib OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/miniz_oxide-0.9.1/) |
| mio-1.2.4 | MIT | [Notices](THIRD_PARTY_LICENSES/mio-1.2.4/) |
| moxcms-0.8.1 | BSD-3-Clause OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/moxcms-0.8.1/) |
| notify-8.2.2 | CC0-1.0 | [Notices](THIRD_PARTY_LICENSES/notify-8.2.2/) |
| notify-types-2.3.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/notify-types-2.3.0/) |
| nu-ansi-term-0.50.3 | MIT | [Notices](THIRD_PARTY_LICENSES/nu-ansi-term-0.50.3/) |
| num-0.4.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-0.4.3/) |
| num-bigint-0.4.8 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-bigint-0.4.8/) |
| num-bigint-0.5.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-bigint-0.5.1/) |
| num-cmp-0.1.0 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-cmp-0.1.0/) |
| num-complex-0.4.6 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-complex-0.4.6/) |
| num-conv-0.2.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-conv-0.2.2/) |
| num-integer-0.1.47 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-integer-0.1.47/) |
| num-iter-0.1.46 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-iter-0.1.46/) |
| num-rational-0.4.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-rational-0.4.2/) |
| num-traits-0.2.19 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num-traits-0.2.19/) |
| num_cpus-1.17.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/num_cpus-1.17.0/) |
| once_cell-1.21.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/once_cell-1.21.4/) |
| once_cell_polyfill-1.70.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/once_cell_polyfill-1.70.2/) |
| ordered-float-3.9.2 | MIT | [Notices](THIRD_PARTY_LICENSES/ordered-float-3.9.2/) |
| os_info-3.15.0 | MIT | [Notices](THIRD_PARTY_LICENSES/os_info-3.15.0/) |
| outref-0.5.2 | MIT | [Notices](THIRD_PARTY_LICENSES/outref-0.5.2/) |
| parking_lot-0.12.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/parking_lot-0.12.5/) |
| parking_lot_core-0.9.12 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/parking_lot_core-0.9.12/) |
| pbkdf2-0.13.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/pbkdf2-0.13.0/) |
| percent-encoding-2.3.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/percent-encoding-2.3.2/) |
| pin-project-lite-0.2.17 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/pin-project-lite-0.2.17/) |
| pkg-config-0.3.34 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/pkg-config-0.3.34/) |
| png-0.18.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/png-0.18.1/) |
| potential_utf-0.1.6 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/potential_utf-0.1.6/) |
| powerfmt-0.2.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/powerfmt-0.2.1/) |
| ppv-lite86-0.2.21 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ppv-lite86-0.2.21/) |
| proc-macro2-1.0.107 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/proc-macro2-1.0.107/) |
| pxfm-0.1.30 | BSD-3-Clause OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/pxfm-0.1.30/) |
| quick-error-2.0.1 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/quick-error-2.0.1/) |
| quinn-0.11.12 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/quinn-0.11.12/) |
| quinn-proto-0.11.19 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/quinn-proto-0.11.19/) |
| quinn-udp-0.5.16 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/quinn-udp-0.5.16/) |
| quote-1.0.47 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/quote-1.0.47/) |
| rand-0.10.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rand-0.10.3/) |
| rand-0.8.8 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rand-0.8.8/) |
| rand_chacha-0.3.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rand_chacha-0.3.1/) |
| rand_core-0.10.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rand_core-0.10.1/) |
| rand_core-0.6.4 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rand_core-0.6.4/) |
| rand_pcg-0.10.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rand_pcg-0.10.2/) |
| rayon-1.12.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rayon-1.12.0/) |
| rayon-core-1.13.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rayon-core-1.13.0/) |
| ref-cast-1.0.27 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ref-cast-1.0.27/) |
| ref-cast-impl-1.0.27 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/ref-cast-impl-1.0.27/) |
| referencing-0.33.0 | MIT | [Notices](THIRD_PARTY_LICENSES/referencing-0.33.0/) |
| regex-1.13.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/regex-1.13.1/) |
| regex-automata-0.4.18 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/regex-automata-0.4.18/) |
| regex-syntax-0.8.11 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/regex-syntax-0.8.11/) |
| reqwest-0.12.28 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/reqwest-0.12.28/) |
| ring-0.17.14 | Apache-2.0 AND ISC | [Notices](THIRD_PARTY_LICENSES/ring-0.17.14/) |
| rpassword-7.5.5 | Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rpassword-7.5.5/) |
| rtoolbox-0.0.6 | Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rtoolbox-0.0.6/) |
| rusqlite-0.37.0 | MIT | [Notices](THIRD_PARTY_LICENSES/rusqlite-0.37.0/) |
| rustc-hash-2.1.3 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/rustc-hash-2.1.3/) |
| rustls-0.23.46 | Apache-2.0 OR ISC OR MIT | [Notices](THIRD_PARTY_LICENSES/rustls-0.23.46/) |
| rustls-pki-types-1.16.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/rustls-pki-types-1.16.0/) |
| rustls-webpki-0.103.16 | ISC | [Notices](THIRD_PARTY_LICENSES/rustls-webpki-0.103.16/) |
| ryu-1.0.23 | Apache-2.0 OR BSL-1.0 | [Notices](THIRD_PARTY_LICENSES/ryu-1.0.23/) |
| same-file-1.0.6 | Unlicense/MIT | [Notices](THIRD_PARTY_LICENSES/same-file-1.0.6/) |
| schemars-0.9.0 | MIT | [Notices](THIRD_PARTY_LICENSES/schemars-0.9.0/) |
| schemars-1.2.3 | MIT | [Notices](THIRD_PARTY_LICENSES/schemars-1.2.3/) |
| scopeguard-1.2.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/scopeguard-1.2.0/) |
| serde-1.0.229 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde-1.0.229/) |
| serde-big-array-0.5.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde-big-array-0.5.1/) |
| serde_bytes-0.11.19 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_bytes-0.11.19/) |
| serde_core-1.0.229 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_core-1.0.229/) |
| serde_derive-1.0.229 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_derive-1.0.229/) |
| serde_json-1.0.154 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_json-1.0.154/) |
| serde_path_to_error-0.1.20 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_path_to_error-0.1.20/) |
| serde_spanned-1.1.3 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_spanned-1.1.3/) |
| serde_urlencoded-0.7.1 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_urlencoded-0.7.1/) |
| serde_with-3.24.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_with-3.24.0/) |
| serde_with_macros-3.24.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/serde_with_macros-3.24.0/) |
| serde_yaml_ng-0.10.0 | MIT | [Notices](THIRD_PARTY_LICENSES/serde_yaml_ng-0.10.0/) |
| serdect-0.4.3 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/serdect-0.4.3/) |
| sha1-0.11.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/sha1-0.11.0/) |
| sha2-0.10.9 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/sha2-0.10.9/) |
| sha2-0.11.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/sha2-0.11.1/) |
| sharded-slab-0.1.7 | MIT | [Notices](THIRD_PARTY_LICENSES/sharded-slab-0.1.7/) |
| shlex-2.0.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/shlex-2.0.1/) |
| simd-adler32-0.3.10 | MIT | [Notices](THIRD_PARTY_LICENSES/simd-adler32-0.3.10/) |
| slab-0.4.12 | MIT | [Notices](THIRD_PARTY_LICENSES/slab-0.4.12/) |
| smallvec-1.16.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/smallvec-1.16.5/) |
| socket2-0.6.5 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/socket2-0.6.5/) |
| stable_deref_trait-1.2.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/stable_deref_trait-1.2.1/) |
| strsim-0.11.1 | MIT | [Notices](THIRD_PARTY_LICENSES/strsim-0.11.1/) |
| subtle-2.6.1 | BSD-3-Clause | [Notices](THIRD_PARTY_LICENSES/subtle-2.6.1/) |
| syn-2.0.119 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/syn-2.0.119/) |
| syn-3.0.10 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/syn-3.0.10/) |
| sync_wrapper-1.0.2 | Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/sync_wrapper-1.0.2/) |
| synstructure-0.14.0 | MIT | [Notices](THIRD_PARTY_LICENSES/synstructure-0.14.0/) |
| tempfile-3.27.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/tempfile-3.27.0/) |
| thiserror-2.0.21 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/thiserror-2.0.21/) |
| thiserror-impl-2.0.21 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/thiserror-impl-2.0.21/) |
| thread_local-1.1.10 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/thread_local-1.1.10/) |
| time-0.3.55 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/time-0.3.55/) |
| time-core-0.1.9 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/time-core-0.1.9/) |
| time-macros-0.2.32 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/time-macros-0.2.32/) |
| tinystr-0.8.5 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/tinystr-0.8.5/) |
| tinyvec-1.13.3 | Zlib OR Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/tinyvec-1.13.3/) |
| tokio-1.54.1 | MIT | [Notices](THIRD_PARTY_LICENSES/tokio-1.54.1/) |
| tokio-macros-2.7.2 | MIT | [Notices](THIRD_PARTY_LICENSES/tokio-macros-2.7.2/) |
| tokio-rustls-0.26.6 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/tokio-rustls-0.26.6/) |
| tokio-util-0.7.20 | MIT | [Notices](THIRD_PARTY_LICENSES/tokio-util-0.7.20/) |
| toml-0.9.12+spec-1.1.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/toml-0.9.12+spec-1.1.0/) |
| toml_datetime-0.7.5+spec-1.1.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/toml_datetime-0.7.5+spec-1.1.0/) |
| toml_parser-1.1.5+spec-1.1.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/toml_parser-1.1.5+spec-1.1.0/) |
| toml_writer-1.2.0+spec-1.1.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/toml_writer-1.2.0+spec-1.1.0/) |
| tower-0.5.3 | MIT | [Notices](THIRD_PARTY_LICENSES/tower-0.5.3/) |
| tower-http-0.6.11 | MIT | [Notices](THIRD_PARTY_LICENSES/tower-http-0.6.11/) |
| tower-layer-0.3.3 | MIT | [Notices](THIRD_PARTY_LICENSES/tower-layer-0.3.3/) |
| tower-service-0.3.3 | MIT | [Notices](THIRD_PARTY_LICENSES/tower-service-0.3.3/) |
| tracing-0.1.44 | MIT | [Notices](THIRD_PARTY_LICENSES/tracing-0.1.44/) |
| tracing-attributes-0.1.31 | MIT | [Notices](THIRD_PARTY_LICENSES/tracing-attributes-0.1.31/) |
| tracing-core-0.1.36 | MIT | [Notices](THIRD_PARTY_LICENSES/tracing-core-0.1.36/) |
| tracing-log-0.2.0 | MIT | [Notices](THIRD_PARTY_LICENSES/tracing-log-0.2.0/) |
| tracing-serde-0.2.0 | MIT | [Notices](THIRD_PARTY_LICENSES/tracing-serde-0.2.0/) |
| tracing-subscriber-0.3.23 | MIT | [Notices](THIRD_PARTY_LICENSES/tracing-subscriber-0.3.23/) |
| try-lock-0.2.5 | MIT | [Notices](THIRD_PARTY_LICENSES/try-lock-0.2.5/) |
| typenum-1.20.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/typenum-1.20.1/) |
| unicase-2.10.0 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/unicase-2.10.0/) |
| unicode-ident-1.0.27 | (MIT OR Apache-2.0) AND Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/unicode-ident-1.0.27/) |
| unsafe-libyaml-0.2.11 | MIT | [Notices](THIRD_PARTY_LICENSES/unsafe-libyaml-0.2.11/) |
| untrusted-0.9.0 | ISC | [Notices](THIRD_PARTY_LICENSES/untrusted-0.9.0/) |
| url-2.5.8 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/url-2.5.8/) |
| utf8_iter-1.1.0 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/utf8_iter-1.1.0/) |
| utf8parse-0.2.2 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/utf8parse-0.2.2/) |
| utf_types-1.0.0 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/utf_types-1.0.0/) |
| uuid-1.29.2 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/uuid-1.29.2/) |
| uuid-simd-0.8.0 | MIT | [Notices](THIRD_PARTY_LICENSES/uuid-simd-0.8.0/) |
| vcpkg-0.2.15 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/vcpkg-0.2.15/) |
| version_check-0.9.5 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/version_check-0.9.5/) |
| vsimd-0.8.0 | MIT | [Notices](THIRD_PARTY_LICENSES/vsimd-0.8.0/) |
| walkdir-2.5.0 | Unlicense/MIT | [Notices](THIRD_PARTY_LICENSES/walkdir-2.5.0/) |
| want-0.3.2 | MIT | [Notices](THIRD_PARTY_LICENSES/want-0.3.2/) |
| webpki-roots-1.0.12 | CDLA-Permissive-2.0 | [Notices](THIRD_PARTY_LICENSES/webpki-roots-1.0.12/) |
| winapi-0.3.9 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/winapi-0.3.9/) |
| winapi-util-0.1.11 | Unlicense OR MIT | [Notices](THIRD_PARTY_LICENSES/winapi-util-0.1.11/) |
| winapi-x86_64-pc-windows-gnu-0.4.0 | MIT/Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/winapi-x86_64-pc-windows-gnu-0.4.0/) |
| windows-link-0.2.1 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/windows-link-0.2.1/) |
| windows-sys-0.61.2 | MIT OR Apache-2.0 | [Notices](THIRD_PARTY_LICENSES/windows-sys-0.61.2/) |
| winnow-0.7.15 | MIT | [Notices](THIRD_PARTY_LICENSES/winnow-0.7.15/) |
| winnow-1.0.5 | MIT | [Notices](THIRD_PARTY_LICENSES/winnow-1.0.5/) |
| writeable-0.6.4 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/writeable-0.6.4/) |
| yoke-0.8.4 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/yoke-0.8.4/) |
| yoke-derive-0.8.4 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/yoke-derive-0.8.4/) |
| zerocopy-0.8.63 | BSD-2-Clause OR Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/zerocopy-0.8.63/) |
| zerofrom-0.1.8 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/zerofrom-0.1.8/) |
| zerofrom-derive-0.1.8 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/zerofrom-derive-0.1.8/) |
| zeroize-1.9.1 | Apache-2.0 OR MIT | [Notices](THIRD_PARTY_LICENSES/zeroize-1.9.1/) |
| zerotrie-0.2.5 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/zerotrie-0.2.5/) |
| zerovec-0.11.9 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/zerovec-0.11.9/) |
| zerovec-derive-0.11.7 | Unicode-3.0 | [Notices](THIRD_PARTY_LICENSES/zerovec-derive-0.11.7/) |
| zlib-rs-0.6.8 | Zlib | [Notices](THIRD_PARTY_LICENSES/zlib-rs-0.6.8/) |
| zmij-1.0.23 | MIT | [Notices](THIRD_PARTY_LICENSES/zmij-1.0.23/) |
| zune-core-0.5.3 | MIT OR Apache-2.0 OR Zlib | [Notices](THIRD_PARTY_LICENSES/zune-core-0.5.3/) |
| zune-jpeg-0.5.15 | MIT OR Apache-2.0 OR Zlib | [Notices](THIRD_PARTY_LICENSES/zune-jpeg-0.5.15/) |

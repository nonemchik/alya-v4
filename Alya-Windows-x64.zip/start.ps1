﻿param(
    [string]$Model,
    [string]$BaseUrl,
    [ValidateSet('openai-responses','responses','openai','compatible','ollama','mock')]
    [string]$Provider,
    [string]$KeyEnv,
    [ValidateRange(1,32768)][int]$MaxOutputTokens,
    [switch]$Qwen,
    [switch]$Configure,
    [switch]$Cli,
    [switch]$CheckOnly,
    [ValidateSet('none','bot','user','both')][string]$TelegramMode,
    [string]$TelegramChats,
    [string]$TelegramMemoryChats,
    [switch]$TelegramLogin
)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$utf8 = New-Object System.Text.UTF8Encoding($false)
$localConfig = Join-Path $PSScriptRoot 'config.local.toml'
$envFile = Join-Path $PSScriptRoot '.env'
$candidateConfig = $null
if (($PSBoundParameters.ContainsKey('TelegramChats') -or $PSBoundParameters.ContainsKey('TelegramMemoryChats')) -and -not $TelegramMode) { throw 'Вместе со списком чатов укажите -TelegramMode bot, user или both.' }

function Set-TomlValue([string]$Text, [string]$Section, [string]$Name, [string]$Value) {
    $pattern = '(?ms)(^\[' + [regex]::Escape($Section) + '\]\r?\n)(.*?)(?=^\[|\z)'
    if (-not [regex]::IsMatch($Text, $pattern)) { throw "Не найдена секция $Section" }
    return [regex]::Replace($Text, $pattern, {
        param($match)
        $line = '(?m)^' + [regex]::Escape($Name) + '\s*=.*$'
        $body = $match.Groups[2].Value
        if ([regex]::IsMatch($body, $line)) {
            $body = [regex]::Replace($body, $line, { param($item) "$Name = $Value" })
        } else { $body = $body.TrimEnd() + "`n$Name = $Value`n`n" }
        return $match.Groups[1].Value + $body
    })
}
function Local-EnvValue([string]$Name) {
    $value = [Environment]::GetEnvironmentVariable($Name)
    if ($value) { return $value }
    if (Test-Path -LiteralPath $envFile) {
        foreach ($line in [IO.File]::ReadAllLines($envFile)) {
            if ($line -match ('^\s*' + [regex]::Escape($Name) + '\s*=(.*)$')) {
                return $Matches[1].Trim().Trim([char]34).Trim([char]39)
            }
        }
    }
    return ''
}
function Save-EnvValue([string]$Name, [string]$Value) {
    if ($Value.Contains("`r") -or $Value.Contains("`n") -or $Value.Contains("'")) { throw 'Некорректное значение ключа' }
    $text = [IO.File]::ReadAllText($envFile)
    $pattern = '(?m)^' + [regex]::Escape($Name) + '\s*=.*$'
    $replacement = "$Name='$Value'"
    if ([regex]::IsMatch($text, $pattern)) { $text = [regex]::Replace($text, $pattern, { param($item) $replacement }) }
    else { $text = $text.TrimEnd() + "`n$replacement`n" }
    [IO.File]::WriteAllText($envFile, $text, $utf8)
}
function Ensure-TomlSection([string]$Text, [string]$Section, [string]$Template) {
    if ([regex]::IsMatch($Text, '(?m)^\[' + [regex]::Escape($Section) + '\]\s*$')) { return $Text }
    return $Text.TrimEnd() + "`n`n" + [IO.File]::ReadAllText((Join-Path $PSScriptRoot $Template)) + "`n"
}
function Chat-Array([string]$Text) {
    $items = @($Text.Split(',') | ForEach-Object { if ($_.Trim()) { $id = [long]$_.Trim(); if ($id -eq 0) { throw 'Telegram chat ID не может быть нулём' }; $id } } | Select-Object -Unique)
    return '[' + ($items -join ', ') + ']'
}
function Require-Secret([string]$Name) {
    if (Local-EnvValue $Name) { return }
    Write-Host ('Введите ' + $Name + '. Значение будет сохранено только в .env.')
    $secure = Read-Host $Name -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
        if ([string]::IsNullOrWhiteSpace($plain)) { throw ($Name + ' пуст') }
        Save-EnvValue $Name $plain.Trim()
    } finally { $plain = $null; [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer); $secure.Dispose() }
}

if (-not (Test-Path -LiteralPath $envFile)) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot '.env.example') -Destination $envFile }
if ((Local-EnvValue 'ALYA_API_TOKEN').Length -lt 32) {
    if ([Environment]::GetEnvironmentVariable('ALYA_API_TOKEN')) { throw 'ALYA_API_TOKEN в окружении должен содержать минимум 32 символа' }
    Save-EnvValue 'ALYA_API_TOKEN' ([Guid]::NewGuid().ToString('N') + [Guid]::NewGuid().ToString('N'))
}
if (-not (Test-Path -LiteralPath $localConfig) -or $Configure -or $TelegramMode -or $PSBoundParameters.ContainsKey('TelegramChats') -or $PSBoundParameters.ContainsKey('TelegramMemoryChats')) {
    if (-not $Model -and (-not (Test-Path -LiteralPath $localConfig) -or $Configure)) { $Model = Read-Host 'Введите точное имя модели, доступной вашему API-ключу' }
    if ((-not (Test-Path -LiteralPath $localConfig) -or $Configure) -and [string]::IsNullOrWhiteSpace($Model)) { throw 'Нужно имя модели; его можно передать через -Model' }
    $text = if (Test-Path -LiteralPath $localConfig) { [IO.File]::ReadAllText($localConfig) } else { [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'config/presets/openai.toml')) }
    if ($Model) { $text = Set-TomlValue $text 'llm' 'model' (ConvertTo-Json -InputObject $Model -Compress) }
    if ($Provider) { $text = Set-TomlValue $text 'llm' 'provider' (ConvertTo-Json -InputObject $Provider -Compress) }
    if ($BaseUrl) { $text = Set-TomlValue $text 'llm' 'base_url' (ConvertTo-Json -InputObject $BaseUrl -Compress) }
    elseif ($Provider -eq 'ollama') { $text = Set-TomlValue $text 'llm' 'base_url' '"http://127.0.0.1:11434"' }
    if ($Provider -eq 'ollama' -and -not $PSBoundParameters.ContainsKey('KeyEnv')) { $text = Set-TomlValue $text 'llm' 'api_key_env' '"OLLAMA_API_KEY"' }
    if ($PSBoundParameters.ContainsKey('KeyEnv')) { $text = Set-TomlValue $text 'llm' 'api_key_env' (ConvertTo-Json -InputObject $KeyEnv -Compress) }
    if ($PSBoundParameters.ContainsKey('MaxOutputTokens')) { $text = Set-TomlValue $text 'llm' 'max_output_tokens' ([string]$MaxOutputTokens) }
    if ($Qwen) {
        $text = Set-TomlValue $text 'embeddings' 'provider' '"ollama"'
        $text = Set-TomlValue $text 'embeddings' 'model' '"qwen3-embedding:4b"'
    }
    foreach ($plugin in @('telegram','telegram_user')) {
        $section = 'plugins.' + $plugin
        $selected = if ($plugin -eq 'telegram') { $TelegramMode -in @('bot','both') } else { $TelegramMode -in @('user','both') }
        if ($TelegramMode -and ($selected -or [regex]::IsMatch($text, '(?m)^\[' + [regex]::Escape($section) + '\]'))) {
            if ($selected) {
                $template = if ($plugin -eq 'telegram') { 'config/telegram.example.toml' } else { 'config/telegram-user.example.toml' }
                $text = Ensure-TomlSection $text $section $template
            }
            $text = Set-TomlValue $text $section 'enabled' $(if ($selected) { 'true' } else { 'false' })
            if ($selected -and $PSBoundParameters.ContainsKey('TelegramChats')) { $text = Set-TomlValue $text $section 'allowed_chats' (Chat-Array $TelegramChats) }
            if ($selected -and $PSBoundParameters.ContainsKey('TelegramMemoryChats')) { $text = Set-TomlValue $text $section 'memory_chats' (Chat-Array $TelegramMemoryChats) }
        }
    }
    $candidateConfig = Join-Path $PSScriptRoot ('config.local.pending-' + [Guid]::NewGuid().ToString('N') + '.toml')
    [IO.File]::WriteAllText($candidateConfig, $text, $utf8)
}

$binary = Join-Path $PSScriptRoot 'alya.exe'
if (-not (Test-Path -LiteralPath $binary)) { $binary = Join-Path $PSScriptRoot 'target/release/alya.exe' }
if (-not (Test-Path -LiteralPath $binary)) { $binary = Join-Path $PSScriptRoot 'target/debug/alya.exe' }
if (-not (Test-Path -LiteralPath $binary)) {
    $cargo = Get-Command cargo -ErrorAction SilentlyContinue
    if (-not $cargo -and (Test-Path -LiteralPath '.tools/cargo/bin/cargo.exe')) {
        $env:RUSTUP_HOME = Join-Path $PWD '.tools/rustup'
        $env:CARGO_HOME = Join-Path $PWD '.tools/cargo'
        $env:RUSTUP_TOOLCHAIN = 'stable'
        $cargo = Get-Item -LiteralPath '.tools/cargo/bin/cargo.exe'
    }
    if (-not $cargo) { throw 'Нужен готовый alya.exe либо Rust: https://rustup.rs' }
    $cargoPath = if ($cargo.Source) { $cargo.Source } else { $cargo.FullName }
    $env:CARGO_INCREMENTAL = '0'
    & $cargoPath build --locked --bin alya
    if ($LASTEXITCODE -ne 0) { throw 'Сборка не завершена' }
    $binary = Join-Path $PSScriptRoot 'target/debug/alya.exe'
}
$validationConfig = if ($candidateConfig) { $candidateConfig } else { $localConfig }
try {
    & $binary --config $validationConfig config validate
    if ($LASTEXITCODE -ne 0) { throw 'Конфигурация некорректна; предыдущие настройки сохранены' }
    $settingsJson = & $binary --config $validationConfig config inspect
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось прочитать настройки; используйте alya.exe из того же комплекта' }
    $settings = $settingsJson | ConvertFrom-Json
    if ($candidateConfig) {
        if (Test-Path -LiteralPath $localConfig) { Copy-Item -LiteralPath $localConfig -Destination ($localConfig + '.backup-' + [Guid]::NewGuid().ToString('N')) }
        Move-Item -LiteralPath $candidateConfig -Destination $localConfig -Force
        Write-Host 'Сохранён config.local.toml. Дополнительные настройки и основной config.toml сохранены.'
    }
} finally { if ($candidateConfig -and (Test-Path -LiteralPath $candidateConfig)) { Remove-Item -LiteralPath $candidateConfig } }
$keyName = [string]$settings.llm.api_key_env
if ($settings.llm.provider -in @('openai','openai-responses','responses','compatible') -and $keyName -and -not (Local-EnvValue $keyName)) {
    Write-Host 'Ключ будет сохранён только в локальном .env. В консоль он не выводится.'
    $secure = Read-Host $keyName -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
        if ([string]::IsNullOrWhiteSpace($plain)) { throw 'API-ключ пуст' }
        Save-EnvValue $keyName $plain.Trim()
    } finally { $plain = $null; [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer); $secure.Dispose() }
}
foreach ($plugin in @('telegram','telegram_user')) {
    $settingsPlugin = $settings.plugins.$plugin
    if ($settingsPlugin -and $settingsPlugin.enabled) {
        if ($plugin -eq 'telegram') { Require-Secret ([string]$settingsPlugin.token_env) }
        else { Require-Secret ([string]$settingsPlugin.api_id_env); Require-Secret ([string]$settingsPlugin.api_hash_env) }
    }
}
if ($TelegramLogin) {
    & $binary --config $localConfig telegram login
    if ($LASTEXITCODE -ne 0) { throw 'Вход в Telegram не завершён. Проверьте API ID/HASH и повторите -TelegramLogin.' }
}
& $binary --config $localConfig personality validate
if ($LASTEXITCODE -ne 0) { throw 'Исправьте файлы personality' }
& $binary --config $localConfig diag
if ($LASTEXITCODE -ne 0) { throw 'Проверка API не пройдена: проверьте ключ, модель и endpoint. Для первого запуска Qwen необязателен.' }
if ($CheckOnly) { Write-Host 'Конфигурация и API проверены. Для запуска повторите команду без -CheckOnly.'; exit 0 }
if ($Cli) { & $binary --config $localConfig chat }
else {
    Write-Host ('Панель: http://' + $settings.api.bind + '/dashboard')
    Write-Host 'В панели нужен ALYA_API_TOKEN из .env или окружения. Ключ OpenAI в панель не вводится.'
    Write-Host 'Для остановки нажмите Ctrl+C. Полное руководство: ALYA_GUIDE.html'
    & $binary --config $localConfig start
}
exit $LASTEXITCODE

@echo off
chcp 65001 >nul
cd /d "%~dp0"
where pwsh.exe >nul 2>nul
if %errorlevel% equ 0 (pwsh.exe -NoProfile -File "%~dp0start.ps1" %*) else (powershell.exe -NoProfile -File "%~dp0start.ps1" %*)
set "alya_exit=%errorlevel%"
if not "%alya_exit%"=="0" pause
exit /b %alya_exit%

# HTTP API

Запуск: `alya start`, по умолчанию `127.0.0.1:3000`. Все private routes требуют `Authorization: Bearer TOKEN`. Scope назначается серверной session; owner/chat из запроса не принимаются. Ответы содержат `x-request-id`, исходные тексты и ключи в tracing не записываются.

## Основные маршруты

| Метод | Маршрут | Права | Назначение |
|---|---|---|---|
| GET | /health, /ready | публичный | Liveness / доступность SQLite; модели проверяются при старте |
| GET | /dashboard, /dashboard.js, /dashboard-graph.js, /dashboard.css, /guide | публичный | Оболочка панели с CSP; данные загружаются с bearer |
| POST | /chat | session | Диалог, optional Idempotency-Key |
| POST | /chat/stream | session | SSE для провайдера с streaming capability |
| POST | /v1/chat/completions | session | Ограниченный OpenAI-compatible text/SSE proxy |
| GET | /memory | session | LongTerm текущего scope |
| GET | /memory/events | session | До 100 последних сырых событий текущего scope в пределах TTL |
| GET | /memory/stats | session | Число документов, событий и векторов |
| POST | /memory/search | session | Scoped hybrid retrieval, body query |
| DELETE | /memory | session | FORGET владельца во всех чатах, включая inbox и video journal |
| DELETE | /memory/{id} | session | Permanent FORGET отдельного воспоминания |
| POST | /memory/consolidate | memory-enabled session | Извлечение/публикация фактов и индексация |
| GET | /memory/pending, /memory/layers | session | Неуверенные факты / пять слоёв |
| POST | /memory/{id}/confirm | memory-enabled session | Подтвердить вариант; альтернативы архивируются |
| POST | /memory/{id}/archive | session | Обратимое архивирование на семь дней |
| POST | /memory/{id}/restore | memory-enabled session | Восстановить архив, если он не истёк и не удалён навсегда |
| GET | /memory/{id}/associations | session | Scoped соседние воспоминания |
| GET | /memory/{id}/backlinks | session | Обратные wikilinks, только тот же owner/chat |
| GET | /relationships | session | Scoped история отношений |
| GET | /personality | session | Identity, traits, graph, self_model |
| POST | /personality/traits, /personality/graph | admin | Сохранить профиль; архивировать предыдущее состояние |
| POST | /personality/self-model | admin | Сохранить привычки, мотивы, цели и манеру речи |
| GET | /personality/history | admin | Метаданные последних 128 изменений профиля |
| POST | /personality/history/{id}/restore | admin | Восстановить изменение с сохранением текущего состояния в истории |
| GET | /plugins | admin | Capabilities и состояния зарегистрированных адаптеров |
| POST | /plugins/{id}/enable, /plugins/{id}/disable | admin | Жизненный цикл настроенного встроенного/внешнего адаптера |
| POST | /media/images | admin | Генерация/редактирование изображения |
| POST | /media/vision | admin | Описание изображения |
| POST | /media/videos | admin | Отправить видеозадачу, получить job_id и status |
| GET | /media/videos/{id} | session, тот же scope | Состояние видеозадачи и готовый provider result |
| DELETE | /media/videos/{id} | session, тот же scope | Отмена, очистка локального файла; remote_cancel/delete при поддержке backend |
| GET | /usage | admin | Durable daily counters/limits, оценочный accounting |
| GET | /diagnostics, /metrics | session | Состояние провайдеров / Prometheus |

## Диалог и повтор запроса

`POST /chat`: `{"message":"Привет","memory_enabled":false}`. Поле memory_enabled необязательно; false всегда запрещает память данного ответа. true не отменяет серверный запрет.

Для разрешённой памяти можно передать `Idempotency-Key` длиной 1–128 ASCII-символов без пробелов. Один key относится к owner/chat и исходному тексту; повтор возвращает зафиксированный ответ и не увеличивает число событий. Повтор key с другим текстом возвращает 409 `idempotency_key_conflict`. Key с отключённой памятью возвращает 400. Не используй key для FORGET-команд. Явный клиентский Idempotency-Key пока поддержан только `/chat`, не stream/proxy маршрутом.

Разрешённые обычные запросы dispatcher записывает в durable inbox и без клиентского key. После сбоя незавершённые запросы разрешённых API scopes восстанавливаются. До атомарной фиксации assistant/state/result возможен повтор модельного inference. После фиксации повтор модели не нужен. Сырой inbox подчинён ShortTerm TTL; после истечения TTL key перестаёт дедуплицировать.

SSE передаёт text_delta/completed/error и не выдумывает streaming для неподдерживаемого провайдера. После обрыва до фиксации частичный текст может отличаться при повторе. Ограничение тела обычного запроса — 32768 байт, сообщения — 16000 байт. Настроенные ключи и bearer-токены в тексте chat/proxy/SSE отвергаются до создания запроса: 400 message_contains_secret, без сохранения входа.

Proxy принимает только model, текстовые messages, stream и optional user. Поддерживается alias alya либо настроенная модель. user не определяет scope; client system/developer цитируются как недоверенные данные. Неизвестные sampling/tools/schema поля отклоняются. Это ограниченная совместимость, не полная замена OpenAI API.

## SelfModel и медиа

SelfModel JSON содержит revision, habits, motivations, goals, speech_markers. Массивы до 16 непустых строк по 512 байт. Revision назначает сервер. Пользовательский чат не имеет инструмента изменения SelfModel или Identity Core.

Image/vision body: `{"prompt":"Описание","images":[{"mime":"image/png","base64":"..."}]}`. Для новой картинки images можно опустить, для vision нужен хотя бы один файл. Разрешены PNG/JPEG/WebP, до четырёх файлов; каждый проверяется полным decode, до 4096×4096 и 64 MiB decode allocations. Тело media image/vision маршрутов ограничено 24 MB, base64 одного файла — 16 MB. Генерация возвращает mime/base64; vision — description.

Video body: `{"prompt":"Описание"}`. Статусы submitting/running/completed/cancelled/unknown/failed. Журнал хранит handles, а не prompt. Polling каждые 10 секунд, retention 48 часов, не больше четырёх активных video jobs на владельца. Отмена не гарантирует отмену внешнего биллинга. Поддерживаются fixed-tariff budget reservations и GET /media/videos/{id}/file для скачивания MP4; автоматическая доставка в мессенджер пока не завершена. Видео поддерживает google_interactions (с явным video_store_consent) либо predict_long_running_compatible backend; retired Veo 3.1 Preview Gemini endpoint отвергается.

Форматы сверялись с официальными [Images edits](https://developers.openai.com/api/reference/resources/images/methods/edit), [Embeddings](https://developers.openai.com/api/reference/resources/embeddings/methods/create) и [Ollama embed](https://docs.ollama.com/api/embed). Контрактные тесты не подтверждают доступность реальных моделей в аккаунте.

Опциональный budget контроллер возвращает429 budget_exceeded до внешнего вызова, учитывает primary/fallback отдельно и сохраняет консервативный резерв при ошибке/cancel. Budgets default off; тарифы задаёт оператор. GET /usage не содержит сообщений/owner IDs. Подробности BUDGETS.md.

## Управление и мозг (0.2.1)

- GET /settings, POST /settings, POST /settings/secrets — admin; atomic save/backup,
  restart_required, существующие ключи не возвращаются.
- GET /brain — memory-enabled session; frame/state/seeds.
- POST /brain/export, /brain/reflect, /brain/development/{revision}/restore — тот же
  scope; reflect использует платный provider и бюджет. POST /personality/cognition
  — admin, проверка исходных параметров.
- POST /plugins/reload, /plugins/invoke — admin; invoke требует разрешённый scope,
  аргументы и проверенный вывод. Host journal защищает idempotent повтор.
- GET /telegram-user/status, POST /telegram-user/action — admin, разрешённые
  account operations и точный advanced RPC allowlist; credentials не передаются модели.
- GET /autonomy, POST /autonomy/consent, DELETE /autonomy/{id} — scoped initiative;
  включение требует rule, global enabled и memory consent.
- GET /moderation — свои записи либо admin аудит текущего чата; POST
  /moderation/{id}/appeal — собственная санкция; /undo и /reject-appeal — admin.

DELETE /memory возвращает pending_plugin_erasures: это число плагинов, чья очистка
ещё не подтверждена. Disabled/removed plugin очищается перед следующим включением.
При ambiguous delivery отправка автоматически не повторяется; exactly-once не обещается.

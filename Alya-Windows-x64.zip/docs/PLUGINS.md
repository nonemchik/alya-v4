# Плагины

SDK1 и Host поддерживают встроенные адаптеры и внешние доверенные программы.
Внешний процесс добавляет мессенджер/игру/инструмент без пересборки Али. Пример:
plugins/examples/game.py + game.toml (в Windows ZIP: plugin-examples).

## Внешний процесс

Скопируйте пример вместе с манифестом в plugins.d, настройте command, allowed_scopes
и enabled. Требуется trusted=true; разрешайте только код, которому доверяете.
Host перечитывает манифесты каждые5 секунд; управление также через /plugins/reload
и панель. Резервные IDs встроенных адаптеров нельзя присваивать внешнему процессу.

Протокол: одна JSON-RPC2 строка на запрос и ответ, совпадающий id; stdout только
для протокола. Максимальный кадр262144 байта, timeout1–120 секунд; process kill
при нарушении/таймауте. Окно консоли Windows скрыто. Переменные окружения очищены,
кроме explicitly allowed_env и необходимого системного окружения. Рабочая папка
— каталог манифеста. Это ограничения контракта, а не OS sandbox.

Обязательные методы: initialize, shutdown, erase_identity. Messenger реализует
receive(limit16), acknowledge(event_id), execute(Action); tool — invoke(scope, function,
arguments). Точные параметры и enums — crates/alya-plugin-sdk/src/lib.rs и
crates/alya-plugin-host/src/external.rs; пример game.py показывает ответ initialize.
Function parameters должны быть strict JSON object schema с additionalProperties=false.
Список функций, capabilities, allowed_scopes/chats задаётся манифестом.

Опциональные методы: memory_allowed(scope), can_moderate(chat,actor,target),
download_attachment(event_id,attachment_id,scope). Download возвращает относительный
путь к проверенному файлу внутри каталога плагина; traversal/symlink запрещены.
Не возвращайте секреты или внутренние инструкции в результаты инструментов.

## Доставка и удаление

PluginJournal в SQLite хранит states/hashes событий и частей ответа без текста
no-memory бесед. Consented завершённый inbox позволяет продолжить неотправленные
части. Неоднозначные sending/generation состояния после сбоя не повторяются;
события имеют ограниченное число попыток. Внешнее exactly-once не обещается.

Stateful tool вызывается со stable request key: параметры canonical-hashed,
проверенный consented результат кэшируется для повторов; неопределённое действие
после сбоя автоматически не исполняется снова. Secret guard работает до SQL cache.
При каждом доступе повторно проверяются scope, capability и состояние плагина.

FORGET записывает durable erasure intent для всех известных плагинов, включая
отключённые/удалённые. Перед следующим включением host сначала вызывает
 erase_identity; при ошибке плагин остаётся выключенным. Удаление считаются
незавершённым, пока callback не подтверждён. API сообщает pending_plugin_erasures.
Автор плагина отвечает за очистку своего состояния и внешнего сервиса.

## Telegram

Bot API: config/telegram.example.toml, TELEGRAM_BOT_TOKEN, allowed_chats.
MTProto: config/telegram-user.example.toml, TELEGRAM_API_ID/HASH и отдельная сессия.
Мастер start.ps1 поддерживает bot/user/both/none, списки чатов и -TelegramLogin.
CLI: telegram login/dialogs/history. Аккаунт использует grammers0.12 и rusqlite
session, не Bot API. Account API доступен только владельцу.

Оба адаптера проверяют allowlist, addressing, sender IDs и согласие. При overlap
отвечает user adapter. В группах нужны имя/mention/reply. /memory on|off,
/forget, /initiative, /moderation, /modlog, /appeal, /undo. Ручные mute/ban требуют
проверки прав отправителя и Али; auto policy отдельно утверждается владельцем.

Поддерживаются входящие photo/image documents для vision, bounded download,
отправка локальных файлов через upload:relative из настроенной uploads-папки,
reactions/edit/replies и ограниченные moderation actions. Расширенный typed RPC
доступен только по точному allowlist; по умолчанию список пуст. Sensitive
 account/auth/payment/phone операции ограничены. VoIP engine отсутствует.

Реальный вход/доставка Telegram не проверялись без аккаунта. Нет untrusted WASM
sandbox и полной generation-to-Telegram media orchestration. Новые мессенджеры
и дополнительные плагины отложены владельцем; текущая работа — Telegram и ядро Али.
Discord и Matrix исключены по просьбе владельца.

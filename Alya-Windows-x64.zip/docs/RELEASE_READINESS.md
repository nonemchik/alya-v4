# Состояние версии0.2.1

**1.0 не объявлена.** Ни контрактные тесты, ни успешная компиляция не доказывают
отсутствие багов и готовность всех внешних интеграций.

| Компонент | Что проверено локально | Что ещё ограничено |
| --- | --- | --- |
| SQLite/FTS/HNSW | Primary SQL, scoped recall, import/mirror, restart, deletion, bounded associations |100k/2560D/concurrent/RAM испытания не выполнены |
| Brain/personality |15 отделов,24 traits,6 дополнительных категорий графа, visual editor, bounded development/rollback, две Obsidian Canvas |Расширенные социальные профили и эмоциональная история ещё не завершены |
| Runtime/LLM |Durable consented inbox, cancellation, output/input secret guards, budget/fallback, SSE/tools |Live inference, quality/personality evals, accurate tokenizer/invoice accounting не подтверждены |
| Plugins |Внешний JSON-RPC loader, reload/lifecycle/schema/scope, idempotent tool calls, erasure queue |Только trusted native; WASM sandbox отсутствует. Новые плагины отложены владельцем |
| Telegram |Bot API и MTProto, login CLI, rights/allowlist/consent, attachments, account API/RPC restrictions |Live account не проверен; VoIP отсутствует; advanced Telegram API требует allowlist |
| Delivery |Durable event/part receipts, ambiguous send не повторяется, restart/revoke/FORGET regressions |Нет exactly-once гарантии внешнего действия/оплаты |
| Images/vision |Независимые providers/keys, generate/edit, validated incoming attachments |Полная generation→Telegram orchestration/album handling ещё не завершена |
| Video |Durable jobs, MP4 download, scoped BLOB, compatible/Interactions, remote cancel/delete по явной отмене |Live backend не проверен; автоматическая remote cleanup при FORGET не реализована |
| Initiative/moderation |Scheduler, consent, limits/quiet hours, policy/permissions, audit/appeal/undo |Нужны дополнительные wired controller/unknown/cancellation tests и полное восстановление прежних permissions |
| Dashboard/guide |Новый black/white UI, формы, session isolation,7-section offline guide, headers/CSP/JS |Визуальный screenshot QA заблокирован browser URL policy |
| Privacy/operations |Owner/scope erasure, locks, durable recovery, no-memory;7 backup/restore тестов с erasure ledger, сверкой расходов и остановкой действий |Длительный stress не выполнен |
| Windows |Launcher smoke bot/user/both/none; извлечённый предыдущий ZIP принят, включая backup/restore |Свежий ZIP с графом/Canvas, backup/restore и assets принят |
| Linux/Docker |Исходники/scripts/compose сохранены |Нет запуска в этой среде; Docker недоступен |
| Discord / Matrix |Исключены владельцем |Не добавляются |

Последний полный workspace прогон: **277 Rust tests PASS**. Clippy --all-targets -D
warnings, Node dashboard tests и offline guide checks PASS. Fixtures изолированы,
пользовательские .env/data/vault не используются. Новый guide собран перед Rust
compile, чтобы /guide и самостоятельный HTML соответствовали друг другу.

Performance на10k synthetic64D: ANN p95 1.870мс, FTS p95 .190мс, hybrid p95 1.625мс,
повторное открытие190мс, Recall@10=1.0. Это40 запросов, файловый кэш ОС не очищался;
не production SLO. [Методика и ограничения](PERFORMANCE.md).

Нужно настроить собственные ключи/модели и проверить реальные Telegram/AI-сервисы.
Внешний native plugin работает с правами пользователя. Старые private backups сохраняют личные данные. restore-backup требует актуальные
метаданные исходной установки; пустой Vault не может согласовать новые удаления.
Ручное копирование базы в обход этого маршрута может вернуть забытое. Текущая версия пригодна для локальных проверок в пределах
реализованных возможностей; весь исходный master prompt ещё не закрыт.

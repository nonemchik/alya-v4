# Память

## Хранилища и scope

ShortTerm — полные разрешённые user/assistant сообщения в SQLite events до 48 часов. LongTerm хранится в SQLite. UUID-файлы Markdown в LongTerm/ с YAML/JSON frontmatter — Obsidian-зеркало; FTS5 и ANN являются пересоздаваемыми индексами. Legacy primary_storage="markdown" оставлен для совместимости, default="sqlite". Потеря основной SQLite-базы не считается полной восстанавливаемостью из заметок: в ней есть состояния и служебные журналы. Профиль личности и Identity Core управляются владельцем отдельно от пользовательской памяти.

Все операции поиска/экспорта проверяют owner и chat; ANN дополнительно отделён fingerprint backend/model/dimensions/query preprocessing. Проверка выполняется до поиска, при чтении кандидата и непосредственно перед включением текста в prompt. Markdown и текст найденных воспоминаний считаются данными, а не инструкциями.

Слой 0 представлен версионированной identity; слой 1 — профилем и постоянными предпочтениями; слой 2 — подтверждённой autobiographical memory и историей отношений; слой 3 — недавними событиями; слой 4 — рабочей историей и текущим эмоциональным состоянием. Identity/personality нельзя записывать через обычный memory API.

## Hybrid RAG и индексация

FTS5 BM25 + HNSW + Reciprocal Rank Fusion k=60; затем importance/confidence/recency и scoped association expansion. Retrieval доступен без буквального триггера. Явное «помнишь» при слабом совпадении вызывает инструкцию уточнить. Confidence ниже 0.5 исключает запись из уверенного поиска. Context ограничен числом символов, не точным tokenizer budget; полный cost/token controller ещё не реализован.

HNSW использует instant-distance, immutable base и сохраняемый delta overlay. Небольшие добавления/изменения не перестраивают base. Каждые 30 секунд server scheduler может подготовить compaction при delta > max(64, base/4), построить граф в spawn_blocking вне storage gate и опубликовать его только при неизменной revision. Изменение данных или FORGET делают готовую сборку неактуальной. Первичная сборка и физическое удаление вектора из base остаются синхронными.

Формат System/ann содержит SHA-256 envelope, scope, fingerprint, dimensions и revision. Некорректный cache восстанавливается из SQLite. При FORGET удалённый вектор физически убирается из persisted base; при полном erasure удаляются все shards владельца. Large-Vault recall/latency benchmarks пока не выполнены.

Сохранённые векторы документов переиспользуются. Новые/изменённые документы отправляются пакетами; ответы проверяются целиком до записи. Повторная проверка исходного body после await не позволяет записать vector для уже изменённого/удалённого документа. Поисковые тексты не остаются в дополнительном embedding cache.

## Obsidian

Файлы имеют стабильное имя UUID.md; owner/chat не могут быть переназначены даже после потери SQLite благодаря ownership ledger. YAML anchors/aliases/tags не принимаются. Предел frontmatter 32 KiB, body 128000 bytes. Запись файлов атомарна, содержимое проверяется checksum/схемой.

Поддерживаются [[UUID]], [[UUID|подпись]], [[LongTerm/UUID.md#раздел|подпись]]. Ссылки связывают только существующие достоверные записи того же owner/chat. Для них доступны backlinks и association expansion. Произвольные названия файлов и title-based identity не поддерживаются. Фрагменты в fenced code не превращаются в связи.

Native notify watcher coalesces изменения LongTerm; проверка раз в две секунды. Страховочная сверка — раз в минуту, при недоступности watcher используется polling. Явный rebuild и startup reindex тоже поддержаны. Граф ассоциаций перестраивается только при изменении signature документов; lexical rebuild всё ещё имеет квадратичную сложность при изменениях.

## Консолидация и восстановление

Сон выполняется независимо от API chat connection и отменяется при erasure владельца. Сырые сообщения не удаляются ради извлечения фактов. LLM получает JSON Schema facts[], известные scoped ключи и одно исходное событие. Каждый факт содержит body/key/value/importance/confidence. Важность ниже порога не закрепляется; сомнительный или конфликтующий вариант получает confidence 0.4 и требует подтверждения.

Source provenance, deterministic fact UUID, batch_jobs и fact sidecars обеспечивают повторяемую публикацию после сбоя. Несколько значимых фактов одного события не смешиваются. Legacy single-fact fixtures/API helpers сохранены для совместимости. Стемминг-проверка значения по источнику консервативна и не заменяет полноценную семантическую верификацию.

Подтверждение одного конфликтующего варианта архивирует альтернативы. Подтверждённые preference.* факты обновляют предпочтения собеседника. История отношений хранит тип/силу события без повторного сохранения текста.

## Durable inbox

Разрешённые запросы dispatcher фиксируются в inbox до помещения в очередь; отклонённый новый запрос удаляется из inbox. Стабильные event IDs исключают дубли ShortTerm. Assistant event, state и replayable result фиксируются одной SQL-транзакцией. После успешной фиксации повтор key возвращает тот же результат без модели; до неё upstream inference может повториться.

Idempotency key привязан к owner/chat и исходному тексту. API восстановление выполняется только для текущих разрешённых scopes. Для Telegram повтор update использует event_id. No-memory запросы в inbox не попадают. TTL inbox равен ShortTerm TTL. Этот журнал не гарантирует exactly-once биллинг или внешнюю доставку сообщений.

## Удаление

FORGET отдельной записи очищает Markdown, FTS, SQLite, вектор и связи; исходная переписка остаётся самостоятельным ShortTerm хранилищем до TTL. Full owner FORGET отменяет активные chat/sleep/media операции и queued events; удаляет LongTerm, ShortTerm, inbox, video handles/results, state, relationships, sidecars/jobs/archives/ownership и ANN владельца. Другие владельцы сохраняются.

Archive обратим до семи дней. Permanent FORGET оставляет UUID tombstone без текста/owner/chat; RESTORE его не снимает. Журналы owner deletion и fact batches позволяют завершить прерванные операции после рестарта. Не удаляй tombstones при восстановлении Vault.

SQLite secure_delete и WAL checkpoint используются после erasure/retention. Это не гарантирует стирания SSD snapshots или внешних копий. Offline backup/restore использует SHA256 manifest, актуальные owner erasure revisions и UUID-tombstones, включая очистку старого working context. Restore требует исходную установку с актуальным Vault и создаёт новый destination; scheduled backups отсутствуют, очистка старых private копий остаётся обязанностью оператора. См. BACKUPS.md. Подробности: DEPLOYMENT.md и PRIVACY.md.

# Аля Nonemchik

Версия **0.2.1**. Rust-движок ИИ-персонажа с Telegram Bot API и MTProto-аккаунтом,
SQLite-памятью, Obsidian-мозгом и внешними дополнениями. Готовый Windows-комплект:
`dist/Alya-Windows-x64.zip`. [Компактный гайд](../ALYA_GUIDE.html) работает offline.

## Запуск Windows

Распакуйте архив в отдельную папку и откройте **Start Alya.cmd**. Укажите точное
имя доступной вам модели и введите API-ключ в скрытом приглашении. Мастер создаёт
`.env` и `config.local.toml`, сохраняет существующие настройки и проверяет модель.
Панель: `http://127.0.0.1:3000/dashboard`; вход по `ALYA_API_TOKEN` из локального
`.env`. Это отдельный токен управления, а не ключ AI-провайдера.

```powershell
.\start.ps1 -Configure -Provider openai-responses -Model "ИМЯ_МОДЕЛИ"
.\start.ps1 -TelegramMode both -TelegramChats "123456789" -TelegramLogin
.\start.ps1 -CheckOnly
```

Остановка — Ctrl+C. Поддерживаются Responses, Chat Completions, compatible API и
Ollama. В исходниках config.toml использует offline mock; в Windows-комплекте
config.toml — preset для настоящей модели, а config/offline-test.toml — для тестов.
Embeddings подключаются отдельно; без них работает FTS5. Модели и тарифы задаёт
оператор. [Быстрый старт](QUICKSTART.md), [лимиты расходов](BUDGETS.md).

## Память и личность

SQLite — основная память. Markdown/Canvas — дополнительное представление и
проверяемый импорт Obsidian; отсутствие .md не удаляет SQL-факт. ShortTerm живёт
не больше48 часов. LongTerm, отношения, эмоции и развитие разделены по owner/chat.
No-memory запрос не читает и не записывает персональную память. /forget отменяет
активную обработку владельца и удаляет сохранённые данные; старые внешние backup
не очищаются автоматически. Подробности: [MEMORY](MEMORY.md), [PRIVACY](PRIVACY.md).

15 отделов мозга собирают единый контекст ответа: Id/Ego/Superego, память,
эмоции, отношения, рефлексия и другие функции. 24 черты, SelfModel, веса отделов,
юмор, ирония, мат, флирт и двусмысленности настраиваются отдельно. Нулевой стиль
остаётся выключенным при развитии. Bounded развитие сохраняется в SQLite,
история доступна для отката. Canvas и связанные заметки экспортируются из панели.
Это модель ИИ-персонажа, а не утверждение о сознании. [PERSONALITY](PERSONALITY.md).

HNSW использует in-memory delta, persisted checkpoints и background compaction с
revision CAS. SQLite восстанавливает незавершённый кэш после сбоя; FORGET физически
очищает persisted vectors. Ассоциации ограничены по числу кандидатов и соседей,
scoped wikilinks сохраняются. [Измерения1000/10000 фактов](PERFORMANCE.md).

## Возможности

- Telegram Bot API и полноценный MTProto-аккаунт: phone/code/2FA, разрешённые чаты,
  память по согласию, replies, медиа, reactions, moderation, owner-only account API.
  Расширенный Telegram RPC требует явного allowlist; голосовых звонков нет.
- Внешние trusted JSON-RPC плагины из plugins.d добавляют инструменты и мессенджеры
  без пересборки ядра. Пример игры: plugins/examples/game.py + game.toml.
- Durable delivery receipts не повторяют неоднозначную отправку/уже отправленную
  часть. Stateful tools имеют idempotency journal; interrupted action не replay.
  Это не гарантия exactly-once внешней оплаты или доставки.
- Image generation/edit/vision, входящие изображения из Telegram, видеозадачи и
  скачивание MP4 в панели. Модели/ключи image, vision и video независимы.
- Opt-in initiative scheduler и moderation audit/appeal/undo подключены; по
  умолчанию выключены. Ограничения прав проверяются перед действиями.
- Панель в чёрно-белом стиле: диалог, память, мозг/развитие, характер, настройки
  моделей и ключей, аккаунт, плагины. Guide доступен также по /guide.

Native subprocess работает с правами пользователя и **не является OS sandbox**.
WASM sandbox пока не реализован. Discord и Matrix исключены по просьбе владельца.
Семь категорий графа личности и две Obsidian Canvas реализованы. Автоматическая
доставка сгенерированных медиа в Telegram и расширенные социальные профили ещё
требуют завершения. Offline backup/restore с erasure reconciliation описаны в BACKUPS.md. Точные границы —
[RELEASE_READINESS](RELEASE_READINESS.md); выпуск не объявлен1.0.

## Проверки

```sh
cargo test --workspace --locked --offline
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
python scripts/check_guide.py
node scripts/test_dashboard.js
python scripts/smoke_api.py
python scripts/smoke_neural.py
python scripts/smoke_launcher.py
```

Последний полный прогон: **277 Rust tests PASS**; Clippy и проверки UI/гайда PASS.
HTTP fixtures проверяют контракты, не реальные облачные модели. Live Telegram,
OpenAI/Qwen/Google, Linux и Docker не проверялись. Browser policy блокирует
визуальный просмотр локального гайда/панели: screenshots QA не выполнена.
Тесты используют временные синтетические данные. Лицензии Windows-зависимостей:
[THIRD_PARTY_NOTICES](../THIRD_PARTY_NOTICES.md).

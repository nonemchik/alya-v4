# Быстрый старт

Основной маршрут: [компактный offline-гайд](../ALYA_GUIDE.html).

1. Распакуйте Windows ZIP и откройте Start Alya.cmd.
2. Укажите модель и API-ключ; дождитесь успешного старта сервера.
3. Откройте http://127.0.0.1:3000/dashboard и введите ALYA_API_TOKEN из .env.
4. Проверьте диалог. Память в панели включается отдельным флажком.
5. Для остановки нажмите Ctrl+C; для повторного запуска снова откройте мастер.

Для смены провайдера:

```powershell
.\start.ps1 -Configure -Provider compatible -Model "ВАША_МОДЕЛЬ" -BaseUrl "https://ВАШ_СЕРВЕР/v1"
```

Для Ollama: -Provider ollama. Для Telegram:

```powershell
.\start.ps1 -TelegramMode both -TelegramChats "123456789" -TelegramLogin
```

Режимы: none, bot, user, both. Нужны Bot token либо Telegram API ID/hash и локальный
вход по phone/code/2FA. Сессия и ключи остаются на вашем компьютере. Для новой
памяти нужны разрешение чата и согласие пользователя; /memory off отзывает запись,
/forget удаляет старые данные. [Подробнее о плагинах](PLUGINS.md).

-CheckOnly проверяет конфигурацию и модель без Telegram login/network; -Cli
открывает терминальный диалог. Мастер не меняет execution policy Windows.
Embeddings и Qwen не обязательны: SQLite/FTS5 работают без локальной модели.
Модели/ключи в панели требуют перезапуска после сохранения.

Для разработки есть setup.ps1/setup.sh и offline config.toml. В Windows ZIP
offline-конфигурация находится в config/offline-test.toml. Linux/Docker и реальные
аккаунты не проверены; ограничения перечислены в RELEASE_READINESS.md.
Не передавайте .env, сессии, data, vault и private backups вместе с программой.
Discord и Matrix не добавляются.
